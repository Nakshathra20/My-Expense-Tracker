import { Navigate } from "react-router-dom";
import { getToken } from "../api";

function ProtectedRoute({ children }) {
  if (!getToken()) return <Navigate to="/login" />;
  return children;
}

export default ProtectedRoute;
